# Media Storage

Stores files onto YouTube.

## Usage

```
./media_storage encode --input <file> --output <file>
./media_storage decode --input <file> --output <file>
```

## Build 

```
mkdir build
cmake -B build
cmake --build build
```
